# Admin Catalog

لوحة تحكم لإدارة ملف المنتجات باستخدام GitHub Pages وGitHub Actions.

## المميزات:
- تسجيل دخول عبر GitHub OAuth
- رفع ملفات Excel لتحديث المنتجات
- توليد ملف products.js تلقائيًا
- استضافة كاملة عبر GitHub Pages